<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lights_status extends Model
{
    protected $table = 'lights_status';
    public $primaryKey = 'light_no';
}
