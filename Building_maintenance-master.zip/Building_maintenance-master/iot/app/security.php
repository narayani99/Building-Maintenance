<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class security extends Model
{
    protected $table = 'security';
    public $primaryKey = 'id';
}
