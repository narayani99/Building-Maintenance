<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class powerConsumed extends Model
{
    protected $table = 'powerConsumed';
    public $primaryKey = 'id';
}
