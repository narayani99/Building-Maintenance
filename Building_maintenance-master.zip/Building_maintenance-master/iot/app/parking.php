<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class parking extends Model
{
    protected $table = 'parking';
    public $primaryKey = 'id';
}
