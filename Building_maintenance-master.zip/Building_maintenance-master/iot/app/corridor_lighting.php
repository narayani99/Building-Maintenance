<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class corridor_lighting extends Model
{
    protected $table = 'corridor_lighting';
    public $primaryKey = 'id';
    
}
